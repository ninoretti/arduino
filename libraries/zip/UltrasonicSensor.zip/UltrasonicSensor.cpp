#include "UltrasonicSensor.h"

/**
 * @brief Constructor
 * @param pinEcho the echo pin
 * @param pinTrigger the trigger pin
 */
UltrasonicSensor::UltrasonicSensor(int pinEcho, int pinTrigger)
{
  this->pinEcho = pinEcho;
  this->pinTrigger = pinTrigger;

  pinMode(pinTrigger, OUTPUT);
  pinMode(pinEcho, INPUT);
}

/**
 * @brief This method return the distance measured by the sensor
 * @return the distance value in centimeters
 */
long UltrasonicSensor::GetDistance()
{
  // Set the trigger output LOW
  digitalWrite(pinTrigger, LOW);
  // Set the trigger output to HIGH for 10 microseconds
  digitalWrite(pinTrigger, HIGH);
  delayMicroseconds(10);
  digitalWrite(pinTrigger, LOW);
  
  // Detect the time to return using the pulseIn function
  long duration = pulseIn(pinEcho, HIGH);
  long distance = duration/58.31;

  return distance;
}


/**
 * @brief This method return the avarage distance measured by the sensor
 * using multiple measures
 * @ param numIteration represents the number of measures performed for computing the average distance 
 * @return the distance value in centimeters
 */

long UltrasonicSensor::GetAverageDistance(int numIteration)
{
  long distanceAcc = 0;
  long duration    = 0;
  long distance    = 0;
  int  numMeasures = 0;
    
  for(int i=0; i<numIteration; i++)
  {
    // imposta l'uscita del trigger LOW
    digitalWrite(pinTrigger, LOW);
    // imposta l'uscita del trigger HIGH per 10 microsecondi
    digitalWrite(pinTrigger, HIGH);
    delayMicroseconds(10);
    digitalWrite(pinTrigger, LOW);
    
    // calcolo del tempo attraverso il pin di echo
    duration = pulseIn(pinEcho, HIGH);
    distance = duration/58.31;
    
    distanceAcc = distanceAcc + distance;
    if(distance!=0)
      numMeasures++;
  }
  distance = (long) (((float)distanceAcc)/((float)numMeasures));
  return distance;
}




  
  
