#ifndef ULTRASONICSENSOR_H
#define ULTRASONICSENSOR_H

#include "Arduino.h"

/**
 * @brief This class allows to manage the ultrasonis sensor HC-SR04.
 * @author Andrea Primavera.
 * @version 1.0
 * @date 2020/10/14
 */
 class UltrasonicSensor
{

  private:
    int pinEcho;
    int pinTrigger;

  public:
    UltrasonicSensor(int pinEcho, int pinTrigger);

    void SetPinEcho(int pinEcho) {this->pinEcho=pinEcho;}
    void SetPinTrigger(int pinTrigger) {this->pinTrigger=pinTrigger;}
    long GetDistance();
    long GetAverageDistance(int numIteration);
};

#endif
